create procedure insert_data(a integer)
    language sql
as
$$
UPDATE mobile SET price = price + 1 WHERE id = a
$$;

alter procedure insert_data(integer) owner to postgres;

